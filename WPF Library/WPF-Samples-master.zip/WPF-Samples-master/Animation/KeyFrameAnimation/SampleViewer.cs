// // Copyright (c) Microsoft. All rights reserved.
// // Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System.Windows;

namespace KeyFrameAnimation
{
    /// <summary>
    ///     Interaction logic for SampleViewer.xaml
    /// </summary>
    public partial class SampleViewer : Window
    {
        public SampleViewer()
        {
            InitializeComponent();
        }
    }
}