﻿namespace MinimalMVVM
{
    public partial class App
    {
    }
}
