namespace MinimalMVVM.Views
{
    public partial class ConvertWindow
    {
        public ConvertWindow()
        {
            InitializeComponent();
        }
    }
}
