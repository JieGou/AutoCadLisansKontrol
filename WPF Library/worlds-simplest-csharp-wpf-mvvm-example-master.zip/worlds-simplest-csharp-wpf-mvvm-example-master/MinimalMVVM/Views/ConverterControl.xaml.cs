﻿namespace MinimalMVVM.Views
{
    public partial class ConverterControl
    {
        public ConverterControl()
        {
            InitializeComponent();
        }
    }
}
