worlds-simplest-csharp-wpf-mvvm-example
=======================================

The World's Simplest C# WPF MVVM Example as described [here](http://www.markwithall.com/programming/2013/03/01/worlds-simplest-csharp-wpf-mvvm-example.html).
