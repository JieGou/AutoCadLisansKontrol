﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaterialDesignDemo.TransitionsDemo
{
    public class Slide7_MasterModel
    {
    }

    public class Slide8_DetailsModel
    {

    }
}
